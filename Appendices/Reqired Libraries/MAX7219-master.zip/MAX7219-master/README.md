MAX7219
=======

Arduino library for MAX7219 display using SPI.


For details about the theory, wiring, schematic, etc. see:

http://www.gammon.com.au/forum/?id=11516

